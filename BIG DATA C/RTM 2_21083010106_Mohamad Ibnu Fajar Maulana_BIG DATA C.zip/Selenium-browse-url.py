from selenium import webdriver
import re
import sys,getopt
import argparse
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By

chrome_options=webdriver.ChromeOptions()
chrome_options.add_argument('--headless')
driver=webdriver.Chrome(ChromeDriverManager().install(),chrome_options=chrome_options)
pattern = re.compile(r'\\\n')
full_txt=[]

def parse_args():
    parser=argparse.ArgumentParser()
    parser.add_argument('-i','--infile',default='',help='input filename')
    parser.add_argument('-o','--outfile',default='',help='outfile filename')
    return parser.parse_args()

def main():
    args=parse_args()
    outfile=args.outfile
    infile=args.infile

    with open(infile) as f:
        content=f.read().splitlines()
    f.close()
    f=open(outfile,'w')

    for u in content:
        driver.get(u)
        elemns=driver.find_element(By.TAG_NAME,'body').text
        menyaring_text=[line for line in elemns.split('\n')if not pattern.search(line)]
        full_txt.append(menyaring_text)
    
    import json
    f.write(json.dumps(full_txt))
    driver.close()
    f.close()
main()
